# Import datasets
# madrid.edges <- read.table("~/Documents/Presentation/Comunity detection/madrid-edges.dat", quote="\"", comment.char="")
# madrid.names <- read.table("~/Documents/Presentation/Comunity detection/madrid-names.dat", quote="\"")

# Import libraries
library(igraph)
library(lsa)

#-------------------------------Start work with graphs-------------------------------#

# Read edges
edges = matrix(scan("madrid-edges.dat", 0), ncol=3, byrow=TRUE)

# Read names
names = scan("madrid-names.dat", "a")

# Build graph
g = graph_from_edgelist(edges[,1:2], directed=FALSE)

# Plot the graph
plot(g)

# Store coordinates for the layout in lo
lo = layout_in_circle(g)
plot(g, layout=lo)

# Store coordinates for the layout in lo
lo = layout_on_sphere(g)
plot(g, layout=lo)

# Delete isolated nodes
g=delete_vertices(g, which(degree(g) == 0)) #names = V(g)$names

# Remove multi-edges
g = simplify(g)

# Plot graph after modification
lo = layout_in_circle(g)
plot(g, layout=lo)


#-----------------------------------Descriptive Statistics--------------------------------------------------#

# Work with verticies
# 'Names' - List of names of Terrorists
# the first name
names[1]
# the number of nodes
length(names)

# Work with links
# the number of links
length(edges)

# Degreee of whole networks
degree_terror_graph=degree(g)
degree_terror_graph

# The distribuition of degrees
hist(degree_terror_graph)

# The max degree
max_degree<-max(degree(g))
max_degree

# The terrorist with max degree - Jamal Zougam
V(g)$names = names
names_of_terrorists = V(g)$names
V(g)$names[which(degree(g)==max_degree)]

# Plot with labels
V(g)$size = degree(g)*2
lo = layout_on_sphere(g)
plot(g, layout = lo, vertex.color="red", vertex.frame.color="#555555", vertex.label=names_of_terrorists, vertex.label.color="black", vertex.label.cex=.7) 

# ------------------- HIGHEST DEGREES ----------------------------------------------#
# Find the terrorists with the highest degrees
# First method
V(g)$names[ degree(g)>20]

#Second method
V(g)[ degree(g)>20]
V(g)$names[1] # Jamal Zougam
V(g)$names[3] # Mohamed Chaoui
V(g)$names[7] # Imad Eddin Barakat


# ------------------- BETWEENESS --------------------------------------------------# 
# Find the terrorists with the highest betweenness
betweeness_g_whole<-betweenness(g)
hist(betweeness_g_whole)

# First method
V(g)$names[which(betweeness_g_whole>300)]

# Secon method
V(g)[which(betweeness_g_whole>300)]
V(g)$names[1] # Jamal Zougam
V(g)$names[3] # Mohamed Chaoui
V(g)$names[57] # OM. Othman Abu Qutada


# --------------------------------- CENTRALITY -------------------------------------# 
# Find the terrorists with the highest centrality
g_whole_centrality <- eigen_centrality(g)
hist(g_whole_centrality$vector)

V(g)$names[which(g_whole_centrality$vector>0.8)] #"Jamal Zougam", "Mohamed Chaoui"


####################################################################################                    ############################################################
# --------------------------- Community Detection ---------------------------------#
# Network Centric Community Detection
c1 = cluster_fast_greedy(g)

# memberships of nodes
membership(c1)

# number of communities
length(c1)

# the sizes of community
sizes(c1)

# plot only colored vertex
coords = layout_with_fr(g)
plot(g, vertex.color=membership(c1), layout=coords)

# plot with area
plot(c1, g, layout=coords)


## FIRST COMMUNITY
# members from the first community
V(g)[membership(c1)==1]

# names of members of the first community
names_first_community = V(g)$names[membership(c1)==1]
names_first_community

# the graph of the first community using cluster_fast_greedy
g1_cluster_fast_greedy <- induced.subgraph(g,vids=V(g)[membership(c1)==1])

# Plot the graph of the first community
V(g1_cluster_fast_greedy)$size = degree(g1_cluster_fast_greedy)*2
plot(g1_cluster_fast_greedy, layout=layout_nicely, vertex.color="yellow", vertex.label=names_first_community)
plot(g1_cluster_fast_greedy, layout=layout_in_circle(g1_cluster_fast_greedy), vertex.color="blue", vertex.label=names_first_community)

### SECOND COMMUNITY
# members from the second community
V(g)[membership(c1)==2]

# names of members of the second community
names_second_community = V(g)$names[membership(c1)==2]
names_second_community

#the graph of the second community using cluster_fast_greedy
g2_cluster_fast_greedy <- induced.subgraph(g,vids=V(g)[membership(c1)==2])

# Plot the graph of the second community
V(g2_cluster_fast_greedy)$size = degree(g2_cluster_fast_greedy)*2
plot(g2_cluster_fast_greedy, layout=layout_nicely, vertex.color="blue", vertex.label=names_second_community)
plot(g1_cluster_fast_greedy, layout=layout_in_circle(g1_cluster_fast_greedy), vertex.color="pink", vertex.label=names_second_community)

# !!! by these way can be analize and visualise all communities

##################### ANALYTICS FOR EACH NETWORK ####################################
# FIRST COMMUNITY 

# Find degree of the first community 
degree_g1_cluster_fast_greedy=degree(g1_cluster_fast_greedy)
hist(degree_g1_cluster_fast_greedy)

# Max degree 
max_degree_g1_cluster_fast_greedy<-max(degree(g1_cluster_fast_greedy))
V(g1_cluster_fast_greedy)$names[which(degree(g1_cluster_fast_greedy)==max_degree_g1_cluster_fast_greedy)]

# Highest betweenness
betweenness_g1_clustr_fast_greedy=betweenness(g1_cluster_fast_greedy)
hist(betweenness_g1_clustr_fast_greedy)
V(g1_cluster_fast_greedy)$names[which(betweenness_g1_clustr_fast_greedy>60)]

# Highest centrality
centrality_g1_cluster_fast_greedy <- eigen_centrality(g1_cluster_fast_greedy)
hist(centrality_g1_cluster_fast_greedy$vector)
V(g1_cluster_fast_greedy)$names[which(centrality_g1_cluster_fast_greedy$vector>0.8)] #"Jamal Zougam" "Imad Eddin Barakat" "Amer Azizi"

plot(g1_cluster_fast_greedy, layout=layout_nicely, vertex.color="blue", vertex.size=degree_g1_cluster_fast_greedy, vertex.label=V(g1_cluster_fast_greedy)$names, vertex.label.color = "black")


# SECOND COMMUNITY 

# Find degree of the second community 
names_second_community

degree_g2_cluster_fast_greedy=degree(g2_cluster_fast_greedy)
hist(degree_g2_cluster_fast_greedy)

# Max degree 
max_degree_g2_cluster_fast_greedy<-max(degree(g2_cluster_fast_greedy))
V(g2_cluster_fast_greedy)$names[which(degree(g2_cluster_fast_greedy)==max_degree_g2_cluster_fast_greedy)]

# Highest betweenness
betweenness_g2_clustr_fast_greedy=betweenness(g2_cluster_fast_greedy)
hist(betweenness_g2_clustr_fast_greedy)
V(g2_cluster_fast_greedy)$names[which(betweenness_g2_clustr_fast_greedy>50)]

# Highest centrality
centrality_g2_cluster_fast_greedy <- eigen_centrality(g2_cluster_fast_greedy)
hist(centrality_g2_cluster_fast_greedy$vector)
V(g2_cluster_fast_greedy)$names[which(centrality_g2_cluster_fast_greedy$vector>0.9)]

plot(g2_cluster_fast_greedy, layout=layout_nicely, vertex.color="blue", vertex.size=degree_g2_cluster_fast_greedy, vertex.label=V(g2_cluster_fast_greedy)$names, vertex.label.color = "black")





